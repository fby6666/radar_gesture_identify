clear

% adcData = bin2mat('raw_data\zuoyi\adc_data_Raw_60.bin');
% adcData = bin2mat('up\adc_data_Raw_1.bin');
path = ('D:\matlab\mydir\radar_gesture\processing\up\');
name = ('adc_data_Raw_1.bin');
adcData = bin2mat([path,name]);

[AT_FW, AT_FY] = AT_process(adcData);
[RT, VT, R_axis, V_axis] = RD_process(adcData);
RT = [RT; zeros(32-size(RT,1),32)];

figure
subplot(2,2,1)
imagesc(1:32, R_axis, RT)
xlabel('帧数');ylabel('距离/m');title('RT图');
colormap(gray(64))
subplot(2,2,2)
imagesc(1:32, V_axis, VT)
xlabel('帧数');ylabel('速度/m/s');title('VT图');
colormap(gray(64))

subplot(2,2,3)
imagesc(AT_FW)
xlabel('帧数');ylabel('方位角/度');title('水平方向AT图');
colormap(gray(64))
subplot(2,2,4)
imagesc(AT_FY)
xlabel('帧数');ylabel('俯仰角/度');title('竖直方向AT图');
colormap(gray(64))


imwrite(RT,strcat('test\','rt','.jpg'));
imwrite(VT,strcat('test\','dt','.jpg'));
imwrite(AT_FW,strcat('test\','at_azimuth','.jpg'));
imwrite(AT_FY,strcat('test\','at_elevation','.jpg'));